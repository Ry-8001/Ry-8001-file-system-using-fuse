In order to run for different input files, just change it from the Makefile.
To run the code write "make all" command into terminal